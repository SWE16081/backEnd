package main 

import "fmt" //fmt包中提供格式化，输出，输入的函数.
func main() {
	//要求：要求：请使用一句输出语句，达到输入如下图形的效果
	fmt.Println("姓名\t年龄\t籍贯\t地址\njohn\t20\t河北\t北京")
	
}