package main
import "fmt"

func main(） {
	fmt.Println("姓名\t性别\t籍贯\t住址\ntom\t男\t天津\t北京")
}