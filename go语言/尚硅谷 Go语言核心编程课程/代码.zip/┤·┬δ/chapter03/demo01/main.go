package main
import "fmt"

func main() {
	//定义变量/声明变量
	var i int
	//给i 赋值
	i = 10
	//使用变量
	fmt.Println("i=", i)
}