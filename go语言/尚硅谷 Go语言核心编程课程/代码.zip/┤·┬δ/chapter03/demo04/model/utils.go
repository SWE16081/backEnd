package model

//定义了一个变量
var HeroName string = "宋江"