package utils
import "fmt"
func SayOk(){
	fmt.Println("say ok")
}

