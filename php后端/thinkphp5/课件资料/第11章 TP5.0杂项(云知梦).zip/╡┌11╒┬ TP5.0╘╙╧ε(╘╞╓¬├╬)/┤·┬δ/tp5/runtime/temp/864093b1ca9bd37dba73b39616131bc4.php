<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"C:\AppServ\www\tp5\public/../application/index\view\cookies\add.html";i:1508917874;}*/ ?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	
	<form action="<?php echo url('file'); ?>" method="post" enctype="multipart/form-data">
		<p>
			FILE:
			<input type="file" name="file" id="">
		</p>
		<p>
			<?php echo captcha_img(); ?>
		</p>
		<p>
			CODE:
			<input type="text" name="code" id="">			
		</p>
		<p>

			<input type="submit" value="提交">
		</p>
	</form>
</body>
</html>