<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:66:"C:\AppServ\www\tp5\public/../application/index\view\yzm\index.html";i:1509007465;}*/ ?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<form action="<?php echo url('check'); ?>" method="post">
		<p>
			验证码:
			<!-- <?php echo captcha_img(); ?> -->
			<img src="<?php echo captcha_src(); ?>" alt="">
		</p>
		<p>
			请输入验证码:
			<input type="text" name="code" id="">
		</p>
		<p>
			<input type="submit" value="提交">
		</p>
	</form>
</body>
</html>