<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:67:"C:\AppServ\www\tp5\public/../application/index\view\user\index.html";i:1508920667;}*/ ?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<table width="800px" align="center" border="1">
		<th>ID</th>
		<th>NAME</th>
		<th>PASS</th>

		<?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?>
			<tr>
				<td><?php echo $val['id']; ?></td>
				<td><?php echo $val['name']; ?></td>
				<td><?php echo $val['pass']; ?></td>
			</tr>
			
		<?php endforeach; endif; else: echo "" ;endif; ?>
	</table>

	<?php echo $data->render(); ?>
</body>
</html>