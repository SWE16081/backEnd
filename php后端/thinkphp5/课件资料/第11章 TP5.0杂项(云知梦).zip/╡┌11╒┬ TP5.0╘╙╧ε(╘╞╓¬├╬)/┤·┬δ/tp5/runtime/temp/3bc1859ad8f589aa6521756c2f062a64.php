<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:65:"C:\AppServ\www\tp5\public/../application/index\view\user\add.html";i:1508922239;}*/ ?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<form action="<?php echo url('upload'); ?>" method="post" enctype="multipart/form-data">
		<p>
			File:
			<input type="file" name="file" id="">
		</p>
		<p>
			<input type="submit" value="提交">
		</p>
	</form>
</body>
</html>