<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"C:\AppServ\www\tp5\public/../application/index\view\users\index.html";i:1505732493;}*/ ?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="__STATIC__/bs/css/bootstrap.min.css">
	<script src="__STATIC__/bs/js/jquery.min.js"></script>
	<script src="__STATIC__/bs/js/bootstrap.min.js"></script>
</head>
<body>
	
	<div class="container">

		<div class="panel panel-primary">
			<div class="panel-heading">
				<button class="btn btn-success">用户展示页面</button>
				<a href="/user/create" class="btn btn-danger">添加用户</a>
			</div>
			<div class="panel-body">
				<table class="table table-bordered table-hover">
					<th>ID</th>
					<th>NAME</th>
					<th>PASS</th>
					<th>AGE</th>
					<th>修改</th>
					<th>删除</th>
					<th>删除</th>
					<?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$value): $mod = ($i % 2 );++$i;?>
					<tr>
						<td><?php echo $value['id']; ?></td>
						<td><?php echo $value['name']; ?></td>
						<td><?php echo $value['pass']; ?></td>
						<td><?php echo $value['age']; ?></td>
						<td><a href="/user/<?php echo $value['id']; ?>/edit">修改</a></td>
						<td>
							<form action="/user/<?php echo $value['id']; ?>" method="post">
								<input type="hidden" name="_method" value="delete">
								<button>删除</button>
							</form>
						</td>
						<td>
							<button onclick="del(this,<?php echo $value['id']; ?>)">Ajax_删除</button>
						</td>
					</tr>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</table>
			</div>
		</div>
	</div>
</body>
<script>
	// 删除数据方法
	function del(obj,id){




		// 发送sql语句

		$.post('<?php echo url("ajax_del"); ?>',{id:id},function(data){

			// 判断是否成功

			if (data.statu==200) {

				$(obj).parent().parent().remove();
				alert(data.info);


			}else{
				alert(data.info);

			}
		});
	}
</script>
</html>