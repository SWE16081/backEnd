<?php 
// 声明命名空间
namespace app\index\controller;

// 声明控制器
class User{

	// index 方法

	public function index(){
		return "我是前台User控制器中的index方法";
	}
}




 ?>