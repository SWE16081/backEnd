<?php 
// 声明命名空间
namespace app\admin\controller;

// 声明控制器

class Index{
	public function index(){

		return "我是后台的控制器";
	}
}



 ?>