<?php 

return [

	"index"=>"我是前台配置",
	// "name"=>"前台配置",

];

 ?>