<?php 

return [

	"name"=>"小郭",
	"love"=>"作家",
	"wai"=>"小四"

];


 ?>