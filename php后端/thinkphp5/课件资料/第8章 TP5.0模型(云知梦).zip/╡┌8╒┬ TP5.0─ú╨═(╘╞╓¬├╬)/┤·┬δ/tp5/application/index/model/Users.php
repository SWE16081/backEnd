<?php

namespace app\index\model;

use think\Model;

class Users extends Model
{
    // 设置查询的数据表

    protected $table="user";
}
