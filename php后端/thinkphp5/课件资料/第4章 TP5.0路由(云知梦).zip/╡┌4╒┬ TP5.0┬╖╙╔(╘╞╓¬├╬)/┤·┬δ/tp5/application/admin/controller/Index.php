<?php 

// 命名空间

namespace app\admin\controller;

// 声明控制器

class Index{

	// 后台首页方法

	public function index(){

		return "我是后台首页";
	}
}

