<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:67:"C:\AppServ\www\tp5\public/../application/index\view\index\type.html";i:1503719643;}*/ ?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<form action="type" method="post">
		
		<p>
			<input type="hidden" name="_method" value="PUT">
			<input type="text" name="name" id="">
		</p>
		<p>
			<input type="submit" value="提交">
		</p>
	</form>
</body>
</html>