<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"C:\AppServ\www\tp5\public/../application/index\view\index\index.html";i:1503574117;}*/ ?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<table border="1" width="800px" align="center">
		<tr>
			<th>ID</th>
			<th>NAME</th>
			<th>PASS</th>
		</tr>

		<?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$value): $mod = ($i % 2 );++$i;?>
			<tr>
				<td><?php echo $value['id']; ?></td>
				<td><?php echo $value['name']; ?></td>
				<td><?php echo $value['pass']; ?></td>
			</tr>
		<?php endforeach; endif; else: echo "" ;endif; ?>

	</table>
</body>
</html>