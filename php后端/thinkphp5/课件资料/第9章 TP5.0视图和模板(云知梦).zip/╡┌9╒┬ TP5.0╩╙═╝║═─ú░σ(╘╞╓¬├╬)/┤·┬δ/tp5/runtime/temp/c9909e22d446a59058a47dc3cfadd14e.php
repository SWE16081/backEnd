<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:69:"C:\AppServ\www\tp5\public/../application/index\view\index\volist.html";i:1508418861;}*/ ?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<p>volist</p>

<!-- 	<?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?>
		<p><?php echo $key; ?> <?php echo $val['id']; ?> <?php echo $val['name']; ?></p>
	<?php endforeach; endif; else: echo "" ;endif; ?> -->

<!-- 	<?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($data) ? array_slice($data,5,5, true) : $data->slice(5,5, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?>
		<p><?php echo $key; ?> <?php echo $val['id']; ?> <?php echo $val['name']; ?></p>
	<?php endforeach; endif; else: echo "" ;endif; ?> -->

<!-- 	<?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;if($mod == '0'): ?>
			<p style="color:red;"><?php echo $key; ?> <?php echo $val['id']; ?> <?php echo $val['name']; ?></p>
		<?php endif; if($mod == '1'): ?>
			<p style="color:blue;"><?php echo $key; ?> <?php echo $val['id']; ?> <?php echo $val['name']; ?></p>
		<?php endif; endforeach; endif; else: echo "" ;endif; ?>  -->


	<!-- <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "没有任何数据" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?>
		<p style="color:blue;"><?php echo $key; ?> <?php echo $val['id']; ?> <?php echo $val['name']; ?></p>
	<?php endforeach; endif; else: echo "没有任何数据" ;endif; ?> -->

	<!-- <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?>
		<p style="color:blue;"><?php echo $key; ?> <?php echo $val['id']; ?> <?php echo $val['name']; ?></p>
	<?php endforeach; endif; else: echo "$empty" ;endif; ?> -->

	<?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $abc = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($abc % 2 );++$abc;?>
		<p style="color:blue;"><?php echo $key; ?> <?php echo $abc; ?> <?php echo $val['id']; ?> <?php echo $val['name']; ?></p>
	<?php endforeach; endif; else: echo "" ;endif; ?>
</body>
</html>