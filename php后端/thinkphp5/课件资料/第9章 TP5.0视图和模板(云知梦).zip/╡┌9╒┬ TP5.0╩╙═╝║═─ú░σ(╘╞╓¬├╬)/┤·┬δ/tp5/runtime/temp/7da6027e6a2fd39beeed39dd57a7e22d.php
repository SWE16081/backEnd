<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:71:"C:\AppServ\www\tp5\public/../application/index\view\index\foreachs.html";i:1508423230;}*/ ?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<h1>foreach</h1>


	<!-- <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): if( count($data)==0 ) : echo "" ;else: foreach($data as $abc=>$val): ?>
		<p> <?php echo $abc; ?> <?php echo $val['id']; ?> <?php echo $val['name']; ?></p>
	<?php endforeach; endif; else: echo "" ;endif; ?> -->

	<h1>For</h1>

	<!-- <?php $__FOR_START_32511__=0;$__FOR_END_32511__=10;for($i=$__FOR_START_32511__;$i < $__FOR_END_32511__;$i+=1){ ?>
		<p><?php echo $i; ?></p>
	<?php } ?> -->
	<!-- <?php $__FOR_START_22046__=0;$__FOR_END_22046__=10;for($abc=$__FOR_START_22046__;$abc <= $__FOR_END_22046__;$abc+=2){ ?>
		<p><?php echo $abc; ?></p>
	<?php } ?> -->

	<!-- <?php $__FOR_START_10841__=10;$__FOR_END_10841__=0;for($i=$__FOR_START_10841__;$i > $__FOR_END_10841__;$i+=-1){ ?>
		<p><?php echo $i; ?></p>
	<?php } ?> -->
	
<!-- 	<?php if($a == '11'): ?>正确<?php endif; if($a != '11'): ?>正确<?php endif; if($a < '11'): ?>正确<?php endif; if($a > '11'): ?>正确<?php endif; if($a >= '11'): ?>正确<?php endif; if($a <= '11'): ?>正确<?php endif; if($a === '11'): ?>正确<?php endif; if($a !== '11'): ?>正确<?php endif; ?> -->

	

<!-- 	<?php if($a == $b): ?>

		<p>a和b数值相等</p>
	<?php else: ?>
		<p>a和b数值不相等</p>

	<?php endif; ?> -->


	<!-- <?php switch($week): case "1": ?>周一<?php break; case "2": ?>周二<?php break; case "3": ?>周三<?php break; case "4": ?>周四<?php break; case "5": ?>周五<?php break; case "6": ?>周六<?php break; default: ?> 周日
	<?php endswitch; ?> -->


<!-- 	<?php if(in_array(($week), explode(',',"0,1,2,3,4,5,6"))): ?>

		合法的数据
		<?php else: ?>
		不合法数据
	<?php endif; ?> -->

<!-- 	<?php $_RANGE_VAR_=explode(',',"0,6");if($week>= $_RANGE_VAR_[0] && $week<= $_RANGE_VAR_[1]):?>
		合法数据
		<?php else: ?>

		非法数据

	<?php endif; ?> -->

<!-- 	<?php 

		echo "123";
	 ?> -->
	
<!-- 	<?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;if($key % 2): ?>
			<p style="color:red"><?php echo $key; ?> <?php echo $val['id']; ?> <?php echo $val['name']; ?></p>
		<?php else: ?>
			<p style="color:blue"><?php echo $key; ?> <?php echo $val['id']; ?> <?php echo $val['name']; ?></p>
		<?php endif; endforeach; endif; else: echo "" ;endif; ?> -->


<!-- 	<?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;
			$sw=$key%3;
		 switch($sw): case "0": ?>
				<p style="color:red"><?php echo $key; ?> <?php echo $val['id']; ?> <?php echo $val['name']; ?></p>
			<?php break; case "1": ?>
				<p style="color:green"><?php echo $key; ?> <?php echo $val['id']; ?> <?php echo $val['name']; ?></p>
			<?php break; case "2": ?>
				<p style="color:blue"><?php echo $key; ?> <?php echo $val['id']; ?> <?php echo $val['name']; ?></p>
			<?php break; endswitch; endforeach; endif; else: echo "" ;endif; ?> -->


	<?php if(is_array($type) || $type instanceof \think\Collection || $type instanceof \think\Paginator): $i = 0; $__LIST__ = $type;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?>

		<h2><?php echo $val['name']; ?></h2>

		<?php if(is_array($val['goods']) || $val['goods'] instanceof \think\Collection || $val['goods'] instanceof \think\Paginator): $i = 0; $__LIST__ = $val['goods'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$goods): $mod = ($i % 2 );++$i;?>

			<p><?php echo $goods['name']; ?> <?php echo $goods['price']; ?></p>
		<?php endforeach; endif; else: echo "" ;endif; endforeach; endif; else: echo "" ;endif; ?>

</body>
</html>