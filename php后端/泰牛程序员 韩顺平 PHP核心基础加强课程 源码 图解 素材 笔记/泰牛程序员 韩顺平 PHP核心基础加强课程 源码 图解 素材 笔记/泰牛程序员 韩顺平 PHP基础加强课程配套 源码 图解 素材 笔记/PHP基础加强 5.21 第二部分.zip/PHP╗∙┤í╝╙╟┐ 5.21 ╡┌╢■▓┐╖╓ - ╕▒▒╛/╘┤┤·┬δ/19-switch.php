<?php
	header("content-type:text/html;charset=utf-8");
	//switch的使用

	/*
	请编写一个程序，该程序可以接收一个字符，比如: a,b,c,d,e,f,g  
a表示星期一，b表示星期二 …  根据用户的输入显
示相应的信息.要求使用 switch 语句完成 
	*/
	
	/*
	$char = 'a';

	switch($char){
		case 'a':
			echo '今天星期一，猴子穿新衣!';
			break;
		case 'b':
			echo '今天星期二，猴子当小二!';
			break;
		default :
			echo '输入有误!';
	}*/


	//细节1: 当一个 case 语句中的值和 switch表达式的值匹配时 PHP 才开始执行语句。

	//细节2: 直到 switch的程序段结束或者遇到第一个 break语句为止。如果不在 case 的语句段最后写上 break的话，PHP 将继续执行下一个 case 中的语句段。
	
	/*
	$char = 'a';
	switch($char){
		case 'a':
			echo '今天星期一，猴子穿新衣!';
			break;
		case 'b':
			echo '今天星期二，猴子当小二!';
			break;
		default :
			echo '输入有误!';
	}

	*/
	//细节3: 一个 case 的特例是 default。它匹配了任何和其它 case 都不匹配的情况

	//细节4: case表达式可以是任何求值为简单类型的表达式，即整型或浮点数以及字符串, 布尔值, array,null 


	$num1 = null;
	
	function getVal($n1, $n2){
		return $n1 + $n2;
	}


	switch($num1){
		case 22.2:
			echo '今天星期一，猴子穿新衣!';
			break;
		case getVal(5,15):
			echo '今天星期二，猴子当小二!';
			break;
		/*case false:
			echo 'hello,world';
			break;*/
		case array(3,9):
			echo 'array(3,9)';
			break;
		case null:
			echo 'null';
			break;
		default :
			echo '输入有误!';
	}

	//细节5: 允许使用分号代替 case 语句后的冒号(不推荐)
	echo '<hr>';
	$char = 'a';
	switch($char){
		case 'a';
			echo '今天星期一，猴子穿新衣!';
			break;
		case 'b';
			echo '今天星期二，猴子当小二!';
			break;
		default ;
			echo '输入有误!';
	}

	//细节6: 在一个 case 中的语句也可以为空，这样只不过将控制转移到了下一个 case 中的语句
	echo '<hr>';
	$char = 'b';
	switch($char){
		case 'a':
		case 'b':
			echo '今天星期二，猴子当小二!';
			break;
		default :
			echo '输入有误!';
	}
	









