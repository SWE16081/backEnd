<?php
	header("content-type:text/html;charset=utf-8");
	

	//逻辑运算的细节
	$num1 = 1;
	$num2 = 1;
	$num3 = 7;
	//说明一下: 当我们进行逻辑与操作时，如果前面的某一个逻辑值为false
	//, 则后面就不再执行，这个就是逻辑与的短路现象
//	if($num2 && $num1 && ++$num3){
//		echo '<br> ok100';
//	}
//
//	var_dump($num1, $num2, $num3);

	//  逻辑或短路
	//说明一下: 当我们进行逻辑或操作时，如果前面的某一个逻辑值为true
	//, 则后面就不再执行，这个就是逻辑或的短路现象
	if($num1 || $num2++){
		echo '<br> ok200<br>';
	}
	echo $num1 . ' ' . $num2;