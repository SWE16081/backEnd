<?php
	
	//
	$step < 1 && $step = 5;
	if($step < 1){
		$step = 5;
	}