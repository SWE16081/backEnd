<?php
	header("content-type:text/html;charset=utf-8");
	//这里是php tplif.php

	//提供数据, 这个数据可能是用户输入的，也可能是从数据库查询得到
	
	$cat_num = rand(1, 10);
	$dog_num = rand(1, 10);
	
	require 'mytpl.html';