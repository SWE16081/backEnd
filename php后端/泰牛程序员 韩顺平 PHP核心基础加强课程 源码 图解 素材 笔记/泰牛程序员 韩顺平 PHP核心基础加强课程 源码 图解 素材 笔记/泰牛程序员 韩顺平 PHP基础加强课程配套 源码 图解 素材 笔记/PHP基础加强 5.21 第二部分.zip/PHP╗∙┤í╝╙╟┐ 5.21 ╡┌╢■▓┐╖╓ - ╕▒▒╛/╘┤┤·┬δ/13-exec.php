<?php
	header("content-type:text/html;charset=gbk");
	//执行运算符, 要注意系统的跨平台问题
	echo '<pre>'; 
	//echo `netstat -anb`;
	echo `ipconfig -all`; // linux `ifconfig`