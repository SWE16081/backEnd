<?php
	header("content-type:text/html;charset=utf-8");
	
	//比较运算符

	 $a=90; $b=90;
	 if($a==$b){ echo "ok1";}
	  $b--;
	 if($a>$b){ echo "ok2";}
	 if($a>=$b){ echo "ok3";}

	 /**

	请编写一个程序，有两个数(可以是整数，也可是小
数),并判断两个数是大于?小于?还是等于?  

	 */

	 $num1 = 2.80001;
	 $num2 = 2.8;

	 $min_val = 0.0000000001;
	 

	 //分支控制
	 if($num1 > $num2){
		echo '$num1 > $num2';
	 }else if($num1 < $num2){
		echo '$num1 < $num2';
	 }else {
		echo '$num1 == $num2';
	 }


	  //分支控制[如果有运算得到的结果]
	 if(round($num1*100000) > round($num2*100000)){
		echo '$num1 > $num2';
	 }else if(round($num1*100000) < round($num2*100000)){
		echo '$num1 < $num2';
	 }else {
		echo '$num1 == $num2';
	 }
		
	 echo '<hr>';
	 if(abs($num1 - $num2) < $min_val){
		echo '$num1 == $num2';
	 }else if($num1 > $num2){
		echo '$num1 > $num2';
	 }else{
		echo '$num1 < $num2';
	 }
	 echo '<hr>';


	 //=== 比较运算符的说明
	 //=== 是说明两个变量的值和类型都相等

	 $n1 = 4;
	 $n2 = 4.0;
	 if($n1 == $n2){
		echo '<br> $n1 == $n2';
	 }

	 if($n1 === $n2){
		echo '<br> $n1 === $n2';
	 }else{
		echo '<br> $n1 === $n2 不成立';
	 }

	//!==  不全等
	// 说明:如果 $a 不等于 $b，或者它们的类型不同， 则返回TRUE
	$a = 123;
	$b = 'hello';
	if($a !== $b){
		echo '<br> $a !== $b';
	}

	$c = 123;
	$d = "123";
	if($c == $d){
		echo '<br>$c == $d';
	}

	if($c !== $d){
		echo '<br> $c !== $d';
	}