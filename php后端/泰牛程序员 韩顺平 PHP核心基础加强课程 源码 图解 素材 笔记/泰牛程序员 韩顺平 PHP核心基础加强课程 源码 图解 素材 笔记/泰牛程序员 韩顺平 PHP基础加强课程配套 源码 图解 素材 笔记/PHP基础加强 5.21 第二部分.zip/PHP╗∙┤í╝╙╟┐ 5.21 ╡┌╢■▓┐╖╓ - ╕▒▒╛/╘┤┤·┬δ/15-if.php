<?php
	header("content-type:text/html;charset=utf-8");
	//分支-if
	/*
	编写一个程序,可以输入人的年龄,如果该同志
的年龄大于18岁,则输出 “你年龄大于18,要对
自己的行为负责!” 
	*/

	$age = 20;
	if($age > 18){
		echo "你年龄大于18,要对自己的行为负责!";
	}

	

