<?php
	header("content-type:text/html;charset=utf-8");
	//字符串运算

	$str1 = 'abc';
	$str2 = '1234';
	$str3 = $str1 . $str2;
	// .= 中间不要有空格
	$str3 .= 'yyy';

	echo $str3;
