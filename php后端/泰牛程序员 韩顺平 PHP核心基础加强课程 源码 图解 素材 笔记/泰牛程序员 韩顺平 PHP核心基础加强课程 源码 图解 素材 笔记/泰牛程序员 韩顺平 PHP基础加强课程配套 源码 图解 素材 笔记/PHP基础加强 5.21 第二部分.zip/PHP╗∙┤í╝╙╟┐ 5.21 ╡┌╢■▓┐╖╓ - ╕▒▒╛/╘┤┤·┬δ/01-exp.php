<?php
	header("content-type:text/html;charset=utf-8");
	
	//说明一下表达式的使用, 任何有值的，都可以看成一个表达式, 
	//不管你的表达式有多么的复杂，最后会返回一个值

	$a = 190;
	$b = 10 + 10 * 3 - (23 + 45 );
	//函数
	function getSum($num1, $num2){
		return $num1 + $num2;
	}

	$y = getSum(90, 0);
	
	
	var_dump($y);

//	$d = ($a > 90) ?  getSum(90, 0) : "不大于";
//	echo $c;
//	echo '<br>$d = ' . $d;
