<?php
	header("content-type:text/html;charset=utf-8");
	//逻辑运算符

	//基本使用
	$a = 90;
	function getVal(){
		return false;
	}
	$a = 
	//!$a 逻辑非  
	//[$a 如果为false , !$a 为true, 如果 $a 为true, !$a 为 false]
	var_dump(!$a);

	if(!getVal()){
		echo '<br> yes';
	}

	//&& 逻辑与
	// 如果 $b 和 $c 都为 TRUE, 则  $b && $c 为 TRUE
	$b = 1;
	$c = 0;

	if($b && $c ){
		echo '<br> ok1';
	}

	//|| 逻辑或
	// 如果 $a 或 $b 任一为 TRUE, 则 $a || $b 返回 true
	$d = false;
	$e = false;
	if($d || $e){
		echo '<br> ok2';
	}

