<?php
	header("content-type:text/html;charset=utf-8");
	//三元运算符的使用
	//三元运算的基本使用是
	//规则：在 expr1 求值为 TRUE 时的值为 expr2，
	//在 expr1 求值为 FALSE 时的值为 expr3

	$a = 90;

	$res = ($a == 1) ? 100 : 'hello';
	echo $res;


	//使用细节

	//1. 三元运算的表达式可以是函数返回的值

	function getSum($num1, $num2){
		return $num1 + $num2;
	}
	function getVal($num1, $num2){
		return $num1 - $num2;
	}

	$num1 = 400;
	$num2 = 200;
	$res2 = $num1 > $num2 ? getSum($num1, $num2) : getVal($num1, $num2);
	echo '<br>' . $res2;

	//2. 关于三元运算的经典使用,用于判断获取的表单数据是否满足条件.
	// Example usage for: Ternary Operator
	//这个地方，使用 isset 判断还是使用 empty 判断，是由你的业务逻辑决定
	//empty 是 "","0","0.0"... 都是为empty
	//isset 是 设置过这个值，并且不为null , 
	//建议 喜欢 isset() && 判断数据合法性
	$action = (empty($_POST['action'])) ? 'default' : $_POST['action'];

	// The above is identical to this if/else statement
	if (empty($_POST['action'])) {
	 $action = 'default';
	} else {
	 $action = $_POST['action'];
	}



