<?php
	header("content-type:text/html;charset=utf-8");
	//赋值运算讲解

	$num1 = 10;
	
	$num2 = 0;
	$num2 += $num1; // 等价 $num2 = $num2 + $num1;
	$num2 -= $num1;
	$num2 *= $num1;
	$num2 /= $num1;
	$num2 %= $num1;
	echo $num2;