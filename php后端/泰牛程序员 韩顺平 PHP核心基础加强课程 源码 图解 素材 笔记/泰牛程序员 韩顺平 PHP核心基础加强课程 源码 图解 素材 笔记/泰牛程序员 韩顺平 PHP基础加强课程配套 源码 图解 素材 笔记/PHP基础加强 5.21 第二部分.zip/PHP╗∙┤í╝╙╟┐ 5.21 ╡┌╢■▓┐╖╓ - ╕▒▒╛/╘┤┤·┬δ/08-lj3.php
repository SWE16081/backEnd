<?php
	header("content-type:text/html;charset=utf-8");
	//逻辑运行练习
	/*
	$a=10; $b=7;
	if($a++>8 || $b++>7){
		echo 'ok!';
	}
	// 11  7
	echo 'a='.$a.'b='.$b;
	*/


	/*$a=10; $b=7;

	if($a++>10 && $b++>7){
		echo 'ok!';
	}
	// a= 11, b=7 
	echo 'a='.$a.'b='.$b;	*/



	$a=10; $b=7;
	if($a++>8 && $b++>7){
		echo 'ok!';
	}
	// a = 11, b = 8
	echo 'a='.$a.'b='.$b;




	

