<?php
	header("content-type:text/html;charset=utf-8");
	//swith 练习

	$a="1";
   switch($a){
   case 1:
	   echo 'hello1';
	   break;
   case 2:
	   echo 'hello2';
	   break;
   default:
	   echo 'default';

   }

	echo '<hr>';
   $a=1.1;
   switch($a){
   case 1.1:
	   echo 'hello1rr';
	   break;
   case 2:
	   echo 'hello2';
	   break;
   default:
	   echo 'default';
   }

	
	echo '<hr>';
	$a=true;
	switch($a){
	case true:
	   echo 'true1';
	   break;
	case 2:
	   echo 'hello2';
	   break;
   default:
	   echo 'default';
   }
	

	 $a=2;
   switch($a){
   case true:
	   echo 'true1';
	   break;
   case 2:
	   echo 'hello2';
	   break;
   default:
	   echo 'default';
   }


	echo '<hr>';
	$i=10;
	switch ($i){
		case 10:
		echo '10';
		case 1.3:
		echo '11';
		break;
		case 1.4:
		echo '12';
		break;
	}

	echo '<hr>';
	$i=11;
	switch ($i){
		default:
		echo 'hello';
		break;
		case 10:
		echo '10';
		case 1.3:
		echo '11';
		break;
		case 1.4:
		echo '12';
		break;
	}

	echo '<hr>';

	$i=11;
	switch ($i){
		default:
		echo 'hello';
		//break;
		case 10:
		echo '10';
		case 1.3:
		echo '11';
		break;
		case 11:
		echo '12';
		break;
	}


