<?php
	header("content-type:text/html;charset=utf-8");
	
	//算术运算符的使用
	
	$num1 = 9;
	$num2 = 8;
	$res1 = $num1 + $num2;
	$res2 = $num1 - $num2;
	$res3 = $num1 * $num2;
	$res4 = $num1 / $num2;

	//这里可以取出两个数相除的余数,
	//1. 判断两个数是否可以整除
	//2. 通常使用%的方式，来换行显示数据
	$res5 = $num1 % $num2;

	//举例
	$arr = array('hello1', 'hello2' , 'hello3', 'hello4' ,'hello3', 'hello4');
	//要求，每行显示两个数据，就换行
	for($i = 0; $i < count($arr); $i++){
		
		echo $arr[$i];
		if(($i+1) % 2 == 0){
			echo '<br>';
		}
	}