<?php
	header("content-type:text/html;charset=utf-8");
	//错误控制运算符

	// 在php的表达式前，加上@,可以忽略错误提示
	// @ 一般来讲，可以和 die 配合使用
	$con = @mysql_connect('localhost', 'root', 'root') or die(mysql_error());

	if($con){
		echo 'ok';
	}else{
		echo 'error';
	}


//	$res = true && false || true;
//	var_dump($res);
//	
//	$res = true || false && true;
//	var_dump($res);
	

	$num = 90;
	$res = 1 + !$num && 90;
	//$res = 1 + false && 90;
	//$res = 1 && 90;
	var_dump($res);
	echo '<br>' . $res;
	

	
	
	