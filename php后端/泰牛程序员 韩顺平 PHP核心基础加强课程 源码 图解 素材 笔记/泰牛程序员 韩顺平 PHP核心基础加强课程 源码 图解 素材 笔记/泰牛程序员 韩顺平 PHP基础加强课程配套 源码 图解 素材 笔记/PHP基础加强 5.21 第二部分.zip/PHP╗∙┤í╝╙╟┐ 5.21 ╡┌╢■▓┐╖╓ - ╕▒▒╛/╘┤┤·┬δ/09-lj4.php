<?php
	header("content-type:text/html;charset=utf-8");
	//逻辑运行的第二细节, 关于优先级的问题
	//这里我们需要分析
	// 通过这个案例，我们得到一个 || 和 or 的区别
	// 1. 他们的优先级是 || 大于 = 大于 or
	// 2. 如果需要执行的结果一样，请使用()括起来.
	$a = false || true; // $a = true
	$b = false or true; // = 优先级 > or  $b = false ;  $b or true 

	var_dump($a, $b);


	//关于两种逻辑与的使用
	echo '<br>';
	$c = true && false; // && 优先级 高于 = , $c 是false
	$d = true and false; // and 优先级 低于 =, $d 是true
	var_dump($c, $d);