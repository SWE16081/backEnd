<?php
	header("content-type:text/html;charset=utf-8");
	//我们接收数据，并处理

	$num1 = isset($_POST['num1']) && is_numeric($_POST['num1']) ? $_POST['num1'] : '';
	$num2 = isset($_POST['num2']) && is_numeric($_POST['num2']) ? $_POST['num2'] : '';
	$oper = isset($_POST['oper']) ? $_POST['oper'] : '';

	//现在对数据进行验证
	if($num1 == '' || $num2 == '' || $oper == ''){
		
		//用一段js来提示信息 => string heredoc
		$info =<<<INFO
	<script>alert('服务器返回信息, 你的数据有误!'); history.back();</script>
INFO;
		echo $info;
	
	//	echo '你的数据有误!';
	//	header('Location: myCal.html');
		//这里我们为什么写上 exit, 表示，该页面不要执行，提高效率
		exit;
	}

	//开始计算 [+ , - , * , /]
	//先定义一个变量，接收运算的结果
	$res = 0;
	switch($oper){
		case '+':
			$res = $num1 + $num2;
			break;
		case '-':
			$res = $num1 - $num2;
			break;
		case '*':
			$res = $num1 * $num2;
			break;
		case '/':
			$res = $num1 / $num2;
			break;
		default :
			echo '你的操作符有误!';
			header('Location: myCal.html');
			exit;
	}

	echo '<h1>运算的结果是' . $res . '</h1>';