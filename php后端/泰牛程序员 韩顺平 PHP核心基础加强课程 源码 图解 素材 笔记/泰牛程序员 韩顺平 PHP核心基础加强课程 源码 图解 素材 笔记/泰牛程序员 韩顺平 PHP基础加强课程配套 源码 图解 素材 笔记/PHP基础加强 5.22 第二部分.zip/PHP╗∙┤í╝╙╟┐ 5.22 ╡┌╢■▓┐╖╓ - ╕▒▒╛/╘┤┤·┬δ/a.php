<?php
	header("content-type:text/html;charset=utf-8");
	
//	function sayOk(){
//		echo 'say Ok, 泰牛!';
//	}


	echo '<br> hello1';