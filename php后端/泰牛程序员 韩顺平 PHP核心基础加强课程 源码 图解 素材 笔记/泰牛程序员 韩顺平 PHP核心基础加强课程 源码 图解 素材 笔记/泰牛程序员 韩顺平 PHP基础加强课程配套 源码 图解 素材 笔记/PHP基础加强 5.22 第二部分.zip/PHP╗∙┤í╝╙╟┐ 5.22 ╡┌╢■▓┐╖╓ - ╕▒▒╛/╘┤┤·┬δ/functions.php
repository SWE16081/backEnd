<?php
	//这里，我们把代码写到一起，做一个函数
	/*
	@getVal 函数名
	@num1 接收的数$num1
	@num2 接收的数$num2
	@oper 接收的运算符
	*/
	function getVal($num1, $num2, $oper){
		$res = 0;
		switch($oper){
			case '+':
				$res = $num1 + $num2;
				break;
			case '-':
				$res = $num1 - $num2;
				break;
			case '*':
				$res = $num1 * $num2;
				break;
			case '/':
				$res = $num1 / $num2;
				break;
			default :
				echo '你的运算符不对';
		}
		//echo 'res = ' . $res;
		return $res;
	}
	