<?php
	header("content-type:text/html;charset=utf-8");
	//b.php 文件，引入 a.php文件
	//第一个方式
	require 'a.php';
	//第二种方式
//	require ('a.php');
	//第三种方式
//	$inc_file = 'a.php';
//	require $inc_file;
	

	//细节说明
	//1. 当我们require 的文件，不存在，则直接退出
	//2. 当我们require 的文件, 不会判断是否已经引入过，而是会重复引入

	echo 'hello';
	echo '<hr>';
	sayOk();

