<!DOCTYPE html>
<html>
 <head>
  <meta charset="utf-8">
  <title> 我的计算器 </title>
  <script type="text/javascript">

	//编写js 的 checkForm
	function checkForm(){
		//获取用户输入的 num1 和  num2
		var num1 = document.getElementById('num1').value;
		var num2 = document.getElementById('num2').value;	
		//如果为空就提示信息，并返回false
		if(num1 == '' ||  num2 == ''){
			alert('输入不能为空');
			return false;
		}else if(isNaN(num1) || isNaN(num2)){
			//我们在判断num1 和 num2是不是一个数 isNaN(num1) ,如果num1不是一个数，就返回true
			alert('输入的不是数值，请重新输入!');
			return false;
		}else{
			return true;
		}
	}

  </script>
 </head>
 <body>
 
  <h1>计算器</h1>
  <!--
  onsubmit="return checkForm()
  当我们提交表单时，去调用(触发) js 的一个函数 checkForm, 该函数需要完成对数据的验证
  -->
  <form action="myCalNew.php" method='post' onsubmit="return checkForm()">
  num1:<input type="text" id="num1" name="num1"><br>
  num2:<input type="text" id="num2" name="num2"><br>
  运算符:
	<select name="oper">
		<option value="+">+</option>
		<option value="-">-</option>
		<option value="*">*</option>
		<option value="/">/</option>
	</select><br>
	<input type="submit" value="提交计算">
  </form>

  <?php
	
	//思考:判断 是否有  $_POST['num1'] ， $_POST['num2']，  $_POST['oper']

	if(isset($_POST['num1']) && isset($_POST['num2']) && isset($_POST['oper'])){

		//我们接收数据，并处理
		$num1 = isset($_POST['num1']) && is_numeric($_POST['num1']) ? $_POST['num1'] : '';
		$num2 = isset($_POST['num2']) && is_numeric($_POST['num2']) ? $_POST['num2'] : '';
		$oper = isset($_POST['oper']) ? $_POST['oper'] : '';

		//现在对数据进行验证
		if($num1 == '' || $num2 == '' || $oper == ''){
			
			//用一段js来提示信息 => string heredoc
			$info =<<<INFO
		<script>alert('服务器返回信息, 你的数据有误!'); history.back();</script>
INFO;
			echo $info;
		
		//	echo '你的数据有误!';
		//	header('Location: myCal.html');
			//这里我们为什么写上 exit, 表示，该页面不要执行，提高效率
			exit;
		}

		//开始计算 [+ , - , * , /]
		//先定义一个变量，接收运算的结果
		$res = 0;
		switch($oper){
			case '+':
				$res = $num1 + $num2;
				break;
			case '-':
				$res = $num1 - $num2;
				break;
			case '*':
				$res = $num1 * $num2;
				break;
			case '/':
				$res = $num1 / $num2;
				break;
			default :
				echo '你的操作符有误!';
				header('Location: myCal.html');
				exit;
		}

		echo '<h1>运算的结果是' . $res . '</h1>';

	}

 ?>
 </body>
</html>
