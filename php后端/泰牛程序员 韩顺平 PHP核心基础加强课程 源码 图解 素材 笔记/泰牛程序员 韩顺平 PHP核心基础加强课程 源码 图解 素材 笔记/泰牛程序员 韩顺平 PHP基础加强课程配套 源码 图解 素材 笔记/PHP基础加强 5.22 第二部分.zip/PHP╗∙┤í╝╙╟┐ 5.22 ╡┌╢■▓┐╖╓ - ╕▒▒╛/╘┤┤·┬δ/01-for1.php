<?php
	header("content-type:text/html;charset=utf-8");
	//for循环

	/*
	  编写一个程序, 可以打印10句 
		  "你好，我是泰牛程序员!”
	*/
	//1. 定义一个循环变量 $i,$j,$k
	for($i = 0; $i < 10; $i++){
	
		echo "<br>你好，我是泰牛程序员! $i";
	}
	
	echo '<hr>';
	//for循环的;之间，可以有多个语句，然后, 隔开
	for($i = 100, $j = 0, $k = 90; $j < 10 && $i > 95 ; $j++, $i--){
		echo '<br>' . $i . ' ' . $j;
	}


	//再看一种写法
	//for循环可以有空语句
	$i = 100;
	$j = 0; 
	$k = 90;
	echo '<hr>';
	for(; $j < 10 && $i > 95 ; ){
		echo '<br>' . $i . ' ' . $j;
		$j++; $i--;
	}


