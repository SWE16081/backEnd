<?php
	header("content-type:text/html;charset=utf-8");
	//魔术常量

	//显示当前是第几行
	echo __LINE__;
	
	//显示当前文件的路径, 不含文件名
	echo __DIR__;
	////显示当前文件的路径, 含文件名
	echo '<br>' . __FILE__;

	echo '<br>' . __FUNCTION__;

	function sayHello(){
		echo '<br> sayHello() ' . __FUNCTION__;
	}
	sayHello();