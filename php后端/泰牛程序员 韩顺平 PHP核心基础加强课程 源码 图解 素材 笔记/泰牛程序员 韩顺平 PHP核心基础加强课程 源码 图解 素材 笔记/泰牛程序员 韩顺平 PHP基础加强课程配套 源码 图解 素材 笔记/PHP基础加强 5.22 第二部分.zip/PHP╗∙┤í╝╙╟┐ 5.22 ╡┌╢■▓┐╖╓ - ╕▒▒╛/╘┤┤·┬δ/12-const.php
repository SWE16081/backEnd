<?php
	header("content-type:text/html;charset=utf-8");
	//常量的使用

	//计算某个人的所得税
	//定义个所得税的税率 0.08 
	define('TAX_RATE', 0.08);
	$salary = 10000;

	$tax = $salary * TAX_RATE;
	echo 'tax = ' . $tax;

	//细节说明
	//1. 常量不能被unset
	//unset(TAX_RATE);
	//2. 常量前面没有$
	//3. 常量定义后不能修改它的值
	//TAX_RATE = 0.07;
	//4. 常量的命名规范是 字母大写加下划线，比如 TAX_RATE, 但是不是必须，而是一种习惯
	define('my_rate', 0.09);
	echo '<br>' . my_rate;

	//5. 我们也可以使用 const 关键字来定义一个常量
	const MY_PI = 3.14;
	echo 'my_pi' . MY_PI;
	//6. 这里define 和 const 的区别: const可以在类中去定义一个类常量,而define不可以.

//	class Dog{
//		//const MY_TAX = 0.08; //(ok)
//		define('MY_TAX', 0.08); //(error)
//	}

	//7. 常量的作用域，可以理解是全局，因此可以在函数中直接使用,不需要声明
	function abc(){
		
		echo 'abc()使用常量' . TAX_RATE;
	}
	abc();