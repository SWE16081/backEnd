<?php
	header("content-type:text/html;charset=utf-8");
	//while循环的讲解

	/*
	  编写一个程序, 可以打印10句 
		  "你好，我是泰牛程序员!”
	*/
	//$i 循环控制变量
	$i = 0;

	while($i < 10){
		echo "<br>你好，我是泰牛程序员! $i" ;
		$i++;
	}