<?php
	header("content-type:text/html;charset=utf-8");
	
	//5.6	变量名，函数名，常量名的可变性讨论

	$a = 'hello,泰牛!';
	$b = 'ok, 你好!';
	$var = 'a';
	

	echo $a;
	echo 'var = ' . $$var;

	function test1(){
		echo '<br>hello,test1()';
	}

	function test2(){
		echo '<br>hello,test2()';
	}

	$myfun = 'test2';

	//正常调用
	test1();

	//通过变量来调用函数
	$myfun();

	//常量也可以使用变量名来调用
	define('P1', 3.14);
	echo '<br>' . P1;
	$my_p1 = 'P1';
	echo '<br>'. constant($my_p1);