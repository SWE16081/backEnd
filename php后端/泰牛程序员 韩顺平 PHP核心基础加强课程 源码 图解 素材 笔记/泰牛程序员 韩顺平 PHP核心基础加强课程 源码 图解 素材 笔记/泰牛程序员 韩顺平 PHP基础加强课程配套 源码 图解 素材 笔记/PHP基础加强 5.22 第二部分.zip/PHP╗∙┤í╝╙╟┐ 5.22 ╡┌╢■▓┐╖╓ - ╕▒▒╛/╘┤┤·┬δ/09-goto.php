<?php
	header("content-type:text/html;charset=utf-8");
	//goto的使用
	
	// a 就是一个label 标记
	goto a;
	echo 'aa';
	a:
	echo 'bb';
