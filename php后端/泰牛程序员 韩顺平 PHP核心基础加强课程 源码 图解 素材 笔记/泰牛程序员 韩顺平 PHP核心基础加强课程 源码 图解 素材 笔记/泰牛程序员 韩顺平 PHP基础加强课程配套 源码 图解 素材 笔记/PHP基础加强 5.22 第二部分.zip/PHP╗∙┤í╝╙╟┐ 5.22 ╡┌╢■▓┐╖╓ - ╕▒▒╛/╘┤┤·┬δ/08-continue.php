<?php
	header("content-type:text/html;charset=utf-8");
	
	/*for($i=0;$i<13;$i++){
		if($i==10){
			continue;
		}
		echo '$i='.$i."<br/>";
	}*/

	for($i=0;$i<2;$i++){
		for($j=1;$j<4;$j++){
			if($j==2){
				continue ;
			}
			echo '$i='.$i.'$j='.$j."<br/>";
		}
	}

	for($i=0;$i<2;$i++){
		for($j=1;$j<4;$j++){
			if($j==2){
				//当continu后面带有数字的时候，continue 可接受一个可选的数字参数来决定跳过几重循环到循环结尾  

				continue  2;
			}
			echo '$i='.$i.'$j='.$j."<br/>";
		}
	}



	

