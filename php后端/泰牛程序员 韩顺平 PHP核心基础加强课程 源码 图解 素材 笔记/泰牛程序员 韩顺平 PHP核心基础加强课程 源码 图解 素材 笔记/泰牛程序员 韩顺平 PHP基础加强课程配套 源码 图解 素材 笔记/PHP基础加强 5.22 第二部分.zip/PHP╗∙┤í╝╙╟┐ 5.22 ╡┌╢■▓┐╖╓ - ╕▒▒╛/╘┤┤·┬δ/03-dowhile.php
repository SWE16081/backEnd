<?php
	header("content-type:text/html;charset=utf-8");
	//do.while
	/**
	编写一个程序(使用do .. while), 可以打印10句 
“你好，我是泰牛程序员!”。请编写程序，
并 画出流程

	*/
	//循环的控制变量
	$i = 0;
	do{
		echo "<br> 你好，我是泰牛程序员! $i";
		$i++;
	}while($i < 10);
