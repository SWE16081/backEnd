<?php
	header("content-type:text/html;charset=utf-8");
	
	//也要计算两个数+ , - ,* , / , %

	$num1 = 90;
	$num2 = 60;
	$oper = '-';
	$res = 0;
	switch($oper){
		case '+':
			$res = $num1 + $num2;
			break;
		case '-':
			$res = $num1 - $num2;
			break;
		case '*':
			$res = $num1 * $num2;
			break;
		case '/':
			$res = $num1 / $num2;
			break;
		default :
			echo '你的运算符不对';
	}

	echo 'res = ' . $res;