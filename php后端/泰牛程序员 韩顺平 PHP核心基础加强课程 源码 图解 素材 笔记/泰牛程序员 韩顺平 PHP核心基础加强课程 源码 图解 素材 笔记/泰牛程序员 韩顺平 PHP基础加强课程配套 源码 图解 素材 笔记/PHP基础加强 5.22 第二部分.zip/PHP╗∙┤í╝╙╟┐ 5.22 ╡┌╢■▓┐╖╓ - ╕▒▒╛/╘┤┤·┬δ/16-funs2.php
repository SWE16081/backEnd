<?php
	header("content-type:text/html;charset=utf-8");
	
	/*
	输入两个数,再输入一个运算符(+,-,*,/)，得到结果
	*/

	$num1 = 100;
	$num2 = 10;
	$oper = '*';
	
	//require '文件的名字'， 这个就是引入
	require  'functions.php';
	//调用函数概念
	//说明，我们的php在执行的时候，是以一个文件为单位执行。
	//也就是说，在执行php代码时，整个文件已经被调入内存
	$res = getVal($num1, $num2, $oper);
	echo 'res = ' .  $res;

	

	
	