<?php
	header("content-type:text/html;charset=utf-8");
	//c.php-require_once

	require_once 'a.php';
	require_once 'a.php';
	require_once 'a.php';


	//1. 当我们require_once 的文件，不存在，则直接退出
	//2. 当我们require_once 的文件, 会判断是否已经引入过，不会重复引入, 这样可以防止引入时，出现函数重复定义问题， 而且有利于性能提高，推荐使用
	echo '<br> 泰牛你好!';
	//sayOk();
