<?php
	header("content-type:text/html;charset=utf-8");
	//e.php 引入a.php
	include_once 'a.php';


	//1. 当我们include_once 的文件不存在，不会退出，会继续执行
	//2. 当我们include_once 的文件, 会判断是否已经引入过，不会重复引入

	echo '<br> e.php';
	sayOk();