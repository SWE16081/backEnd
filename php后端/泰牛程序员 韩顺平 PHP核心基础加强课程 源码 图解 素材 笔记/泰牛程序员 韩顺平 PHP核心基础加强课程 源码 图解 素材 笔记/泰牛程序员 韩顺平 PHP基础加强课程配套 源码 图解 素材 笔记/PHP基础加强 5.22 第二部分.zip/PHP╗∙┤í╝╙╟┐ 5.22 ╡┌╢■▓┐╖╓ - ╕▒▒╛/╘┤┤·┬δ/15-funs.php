<?php
	header("content-type:text/html;charset=utf-8");
	//看看php有多少函数
	
	function sayHello()
	{
	}

	echo '<pre>';
	print_r(get_defined_functions());
