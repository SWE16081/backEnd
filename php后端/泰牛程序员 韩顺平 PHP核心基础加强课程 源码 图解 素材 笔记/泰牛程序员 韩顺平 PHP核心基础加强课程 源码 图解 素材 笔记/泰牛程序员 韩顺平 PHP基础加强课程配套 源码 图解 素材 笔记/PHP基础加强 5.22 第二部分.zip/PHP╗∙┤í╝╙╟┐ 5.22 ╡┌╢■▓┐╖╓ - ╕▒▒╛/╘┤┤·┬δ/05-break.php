<?php
	header("content-type:text/html;charset=utf-8");
	//break的使用
	/*
	随机生成1-1000的一个数，直到生成了99这个数，
看看你一共用了几次?

	*/

	$count = 0;
	while(true){
		$val = rand(1, 1000);
		$count++;
		if($val == 99){
			echo '<br>一共使用了' . $count;
			break;
		}
	}