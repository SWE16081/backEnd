<?php
	header("content-type:text/html;charset=utf-8");
	

	$val = require 'temp2.php';

	var_dump($val);