<?php
	header("content-type:text/html;charset=utf-8");
	/*
	某人有100,000元,每经过一次路口，需要交费,规则如下:
当现金>50000时,每次交5%
当现金<=50000时,每次交5000
编程计算该人可以经过多少次路口.	
	**/
	//思路: 
	//1. 应该有变量存放 $money
	//2. 这里我们使用while 来计算
	//3. 退出while的条件是，我们的 $money不够缴路费
	$money = 100000;
	$count = 0;
	while(true){
		   
		if($money > 50000) {
			//这里我们计算还有多少钱剩下
			$money *= 0.95; 
		}else if($money <= 50000){
			if($money < 5000){
				break;
			}
			$money -= 5000;
		}
		$count++;
	}
	echo '一共可以过' . $count;

