<?php
	header("content-type:text/html;charset=utf-8");
	
	for($i=0,$j=50; $i<10; $i++) {
	  while($j-- < 10) {
		if($j==17) goto end; 
	  }  
	}
	echo "i = $i";
	end:
	echo 'j = 17';
