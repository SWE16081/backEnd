<?php
	header("content-type:text/html;charset=utf-8");
	//d.php 引入 a.php
	include 'a.php';
	include 'a.php';
	include 'a.php';
	include 'a.php';

	
	//1. 当我们include 的文件不存在，不会退出，会继续执行
	//2. 当我们include 的文件, 不会判断是否已经引入过，而是会重复引入

	echo '<hr> 泰牛';
	sayOk();