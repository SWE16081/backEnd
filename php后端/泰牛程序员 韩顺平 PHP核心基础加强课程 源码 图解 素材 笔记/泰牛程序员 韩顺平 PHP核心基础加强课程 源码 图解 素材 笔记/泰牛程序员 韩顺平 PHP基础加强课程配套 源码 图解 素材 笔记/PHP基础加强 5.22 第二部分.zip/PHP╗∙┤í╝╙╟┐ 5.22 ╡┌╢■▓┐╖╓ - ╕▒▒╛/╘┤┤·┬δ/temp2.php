<?php
	//header("content-type:text/html;charset=utf-8");
	
	//echo 'hello';

	return array('no1' => '大威天龙');