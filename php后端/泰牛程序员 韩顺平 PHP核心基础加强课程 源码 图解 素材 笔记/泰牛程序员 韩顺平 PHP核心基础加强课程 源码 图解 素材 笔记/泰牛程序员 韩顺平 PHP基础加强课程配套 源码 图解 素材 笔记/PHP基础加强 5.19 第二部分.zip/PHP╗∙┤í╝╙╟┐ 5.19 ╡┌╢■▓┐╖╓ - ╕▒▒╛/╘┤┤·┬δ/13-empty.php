<?php
	header("content-type:text/html;charset=utf-8");
	//empty的使用说明
	
	//在如下情况，是empty
	//""、0、"0"、NULL、FALSE、array()以及没有任何属性的对象都将被认为是空的
	//除了上面的情况，则是非空
	
	$str = 1;
	if(empty($str)){
		echo 'empty';
	}else{
		echo 'no empty';
	}