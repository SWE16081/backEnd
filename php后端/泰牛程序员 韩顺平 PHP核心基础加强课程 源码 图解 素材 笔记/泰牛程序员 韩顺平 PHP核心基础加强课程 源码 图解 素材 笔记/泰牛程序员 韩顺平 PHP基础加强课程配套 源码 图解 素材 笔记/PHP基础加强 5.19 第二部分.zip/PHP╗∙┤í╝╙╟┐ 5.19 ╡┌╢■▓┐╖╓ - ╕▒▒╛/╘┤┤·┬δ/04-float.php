<?php
	header("content-type:text/html;charset=utf-8");
	//小数的使用说明
	$salary = 13457.98;
	echo '<pre>';
	var_dump($salary);