<?php
	header("content-type:text/html;charset=utf-8");
	
	//基本使用
	$isOk = TRUE;
	$isLogin = FALSE;

	if($isOk){
		echo 'ok';
	}

	//细节说明

	//非0，非空字串，非空的数组，都当做TRUE 
	$a = -1.89;
	if($a){
		echo '<br>$a = 1';
	}
	
	$b = "hello";
	$c = array('no1'=>'北京');
	if($b){
		echo '<br>$b = "hello"';
	}

	if($c){
		echo '$c = array';
	}
	$b = "";
	$c = array();
	if($c){
		echo 'yes';
	}else{
		echo '<br>no';
	}

	/*
	布尔值 FALSE 自身 
	整型值 0 (零) 
	浮点型值 0.0 (零) 
	空 字符串, 以及 字符串 "0" 
	不包括任何元素的数组 
	不包括任何成员变量的对象（仅PHP 4.0 适用）  
	特殊类型 NULL (包括尚未设定的变量)
	从空标记生成的 SimpleXML 对象  
	*/

	$d = NULL;

	if($d){
		echo '<br>$d';
	}else{
		echo '<br> no no $d';
	}