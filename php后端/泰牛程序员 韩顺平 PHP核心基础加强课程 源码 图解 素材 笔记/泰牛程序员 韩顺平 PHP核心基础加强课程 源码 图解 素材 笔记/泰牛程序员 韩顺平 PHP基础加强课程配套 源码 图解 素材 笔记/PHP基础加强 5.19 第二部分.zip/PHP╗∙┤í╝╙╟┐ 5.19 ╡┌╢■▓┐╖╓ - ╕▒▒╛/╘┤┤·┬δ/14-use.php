<?php
	header("content-type:text/html;charset=utf-8");
	
	/**
	当我们接收一个表单提交的数据时，如何防
	止该变量不存在就去接收的问题?

	*/

	$name = isset($_GET['name']) ? $_GET['name']:'';
	
	//如果判断是一个整数?
	$age = (isset($_GET['age']) && is_numeric($_GET['age']) && strpos($_GET['age'], '.') === false) ? $_GET['age'] : '';
	$salary = isset($_GET['salary']) && is_numeric($_GET['salary']) ? $_GET['salary'] : '';
	
	if($name == '' || $age == '' || $salary == ''){
		echo '你的输入有误! 请重新输入';
	}else{
		echo '你输入的信息是 ' . $name . ' ' . $age . ' ' . $salary;
	}