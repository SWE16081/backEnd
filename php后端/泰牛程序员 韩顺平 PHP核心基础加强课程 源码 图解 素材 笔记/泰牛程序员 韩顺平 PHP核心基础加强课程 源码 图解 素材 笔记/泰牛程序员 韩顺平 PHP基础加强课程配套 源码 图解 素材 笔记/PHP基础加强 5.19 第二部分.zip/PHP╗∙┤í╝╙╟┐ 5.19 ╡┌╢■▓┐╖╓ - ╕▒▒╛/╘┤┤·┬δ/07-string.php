<?php
	header("content-type:text/html;charset=utf-8");
	

	function t100(){
		echo 'hello,t1';
	}

	$fun_name = 't1';

	echo "<br>t1()";
	echo '<br>';
	//当php去执行一个""的内容时， 如果它发现有 $变量。
	//他的执行步骤如下  
	//1.先找到一个 $变量的值 2. 当找到该变量后，发现有(),就会尝试去执行这个函数,如果发现该函数，就执行，如果没有发现该函数，就报错  
	echo "{$fun_name()}";
	echo '<br>';
	echo "{t1()}";
