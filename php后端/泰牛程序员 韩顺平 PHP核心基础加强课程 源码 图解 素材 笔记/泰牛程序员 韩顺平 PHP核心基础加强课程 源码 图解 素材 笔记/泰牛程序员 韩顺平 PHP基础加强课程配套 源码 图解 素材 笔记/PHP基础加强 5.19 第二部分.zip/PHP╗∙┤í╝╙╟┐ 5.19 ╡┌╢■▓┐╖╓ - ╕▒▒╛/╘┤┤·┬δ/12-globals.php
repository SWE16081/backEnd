<?php
	header("content-type:text/html;charset=utf-8");

	//$GLOBALS

	echo '<pre>';
	//1. $GLOBALS是一个超全局预定义数组，含有所有的全局变量
	var_dump($GLOBALS);

	//2.定义一个$a全局变量后，自动自动的放入到 $GLOBALS中
	//等价于  $GLOBALS['a'] = 'hello';
	$a = 'hello';	
	var_dump($GLOBALS);
	//echo '<br>' . $GLOBALS['a'];
	//3. 如果我们unset($GLOBALS['a']), 就是把这个数据本身删除
	unset($GLOBALS['a']);
	echo $a;

	//4. 局部变量不会被放入到$GLOBALS数组中