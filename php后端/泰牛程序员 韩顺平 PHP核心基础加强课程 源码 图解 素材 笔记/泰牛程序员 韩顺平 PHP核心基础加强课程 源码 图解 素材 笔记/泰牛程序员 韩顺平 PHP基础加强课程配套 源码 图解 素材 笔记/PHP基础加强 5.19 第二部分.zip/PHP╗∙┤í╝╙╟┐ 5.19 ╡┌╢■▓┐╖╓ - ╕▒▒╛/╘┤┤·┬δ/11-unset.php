<?php
	header("content-type:text/html;charset=utf-8");
	

	//关于unset的细节说明

//	$a = 100;
//	unset($a);
//	echo $a;
	//说明unset 就是把 变量销毁.

	//如果在函数中 unset() 一个全局变量，则只是局部变量被销毁
	
//	$b = 700;
//	function test(){
//		global $b;
//		$b = 10;
//		unset($b);
//	}
//	test();
//	unset($b)
//	echo $b;


	//关于$GLOBALS全局数组的使用

	echo '<pre>';
	//当我创建了一个全局变量时, 该全局变量就会自动的被加入到 $GLOBALS
	$book = '西游记';
	var_dump($GLOBALS);


	//如果您想在函数中 unset() 一个全局变量，可使用 $GLOBALS 数组来实现
	
	$b = 700;
	function test(){
		global $b;
		$b = 10;
		echo '<br> 在test()函数中' . $GLOBALS['b'];
		unset($GLOBALS['b']);
	}
	test();
	echo '<br>' . $b;