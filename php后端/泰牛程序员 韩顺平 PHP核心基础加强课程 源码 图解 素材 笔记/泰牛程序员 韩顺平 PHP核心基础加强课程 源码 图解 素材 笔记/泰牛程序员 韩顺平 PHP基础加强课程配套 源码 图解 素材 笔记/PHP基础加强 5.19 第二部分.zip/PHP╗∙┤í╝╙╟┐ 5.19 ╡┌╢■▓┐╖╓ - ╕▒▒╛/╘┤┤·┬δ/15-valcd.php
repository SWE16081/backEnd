<?php
	header("content-type:text/html;charset=utf-8");
	
	//数据的传递方式
	//值传递
	
	//当把一个变量，定义在函数外，则该变量就是一个全局变量, 该变量
	//就会被放在全局区
	$a = 'abc';
	$b = $a;
	echo $b;
	$b = 45;
	echo '<br>' . $a;

	//-------------
	//引用传递
	$a = 'hello';
	$b = &$a;
	echo '<br>' . $b;
	$b = 45;
	echo '<br>' . $a;


	//我们说明 int , float, bool, string 都是默认值传递
	//数组默认是什么方式传递, 默认是值传递

	$city = array('no1'=>'北京', 'no2'=>'天津');
	$city2 = &$city;

	echo '<pre>';
	var_dump($city);
	var_dump($city2);

	$city2['no1'] = '上海';

	var_dump($city2);
	var_dump($city);


	//对象的传递方式?=>也是值传递，传递的是对象标识符

	//null数据类型也是默认值传递
	$c = null;
	$d = $c;
	$d = 'abc';
	var_dump($c, $d);

	//资源数据类型,默认值传递 
	$con = @mysql_connect('localhost', 'root', 'root');
	var_dump($con);
	
	$con2 = &$con;
	$con2 = null;
	var_dump($con2);
	var_dump($con);

