<?php
	header("content-type:text/html;charset=utf-8");
	//数据类型的强制转换

	//settype
	$num1 = 100;
	//这里我们可以把$num1,强制转成 
	/**
	boolean” （或为“bool”，从 PHP 4.2.0 起） 
	■“integer” （或为“int”，从 PHP 4.2.0 起） 
	■“float” （只在 PHP 4.2.0 之后可以使用，对于旧版本中使用的“double”现已停用） 
	■"string" 
	■ "array" 
	■ "object" 
	■“null” （从 PHP 4.2.0 起） 
	*/
	settype($num1, "string");
	var_dump($num1);



	//使用（类型）变量的方式转换
	//请注意， 使用(类型)变量的方式转换时，对变量本身并没有修改，而是返回的值
	//是转成的对应的类型
	$num2 = 200;
	echo '<br>';
	//这里的(string) 可以是 boolean，integer float string array object
	$a = (array)$num2;
	var_dump($a);
	var_dump($num2);


	//第三种方式，intval(变量), floatval , strval , boolval, 
	//特点说明， 没有改变变量本身的数据类型，而是返回的值是你希望要的
	$num3 = 400;
	$b = floatval($num3);
	echo '<br>';
	var_dump($b, $num3);



