<?php
	header("content-type:text/html;charset=utf-8");

	//php 变量的数据类型是根据赋值的不同而变化
	//这个特点，就是弱数据类型
	$num = 100;
	echo '<pre>';
	var_dump($num);
	
	$num = 'hello';
	var_dump($num);