<?php
	header("content-type:text/html;charset=utf-8");
	
	//字符串的使用细节

	//字符串的使用方法有4种
	//1. 单引号使用
	//  特点 (1) 不会去解析 $ (2) 执行效率高
	$num = 10;
	$address = 'hello,北京 $num';
	echo '<pre>';
	var_dump($address);

	//2. 双引号
	// 特点(1) 会解析 $, (2) 执行效率没有''号 (3) 如果我们在""号要解析含义特殊字符或者数组，则需要{}括起来

	$address = "hello,北京 $num";
	var_dump($address);

	$arr = array('no1'=>'西游记', 'no2'=>'红楼梦');

	$book_list = "书名是 {$arr['no1']}";
	var_dump($book_list);

	//3. heredoc使用
	// 这个heredoc 一般用于返回大段的 HTML代码
	// 使用的注意事项  1. 会解析 $ 2. <<<标识符后面的HTMLCON可以任意，一般是大写 3. <<<HTMLCON 后面不要其它字符 4.  <<<HTMLCON 和后面的定界标示符 HTMLCON相等 5. 最后的 HTMLCON;定格写
	$div_info=<<<HTMLCON
<h1>hello,world!</h1> $num
<h1>hello,world!</h1> $num
<h1>hello,world!</h1> $num
<h1>hello,world!</h1> $num
HTMLCON;
	echo $div_info;

	//4. nowdoc的使用, 类似单引号的使用
	echo '<br>*************************************';
$info=<<<'HTMLCON'
<h1>hello,world!</h1> $num
<h1>hello,world!</h1> $num
<h1>hello,world!</h1> $num
<h1>hello,world!</h1> $num
HTMLCON;
echo $info;


	//关于字符串转义使用说明
	// 如果我们在 ""号中，使用 \x40 16进制的值，对应的ascii字符
	// \101 表示输出 8进制值，对应的   ascii码字符
	// x40 = 0 + 4*16 = 64
	// 101 = 1 + 0*8 + 1*8*8 = 65
	$str = "abc \" \x40 \101 \x61";
	echo $str;

