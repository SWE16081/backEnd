<?php
	header("content-type:text/html;charset=utf-8");
	//isset的使用, 如果变量存在，并不为null, 返回true

	$a = null;
	if(isset($a)){
		echo '$a 存在 ，并且不为null';
	}


	//unset的使用 销毁指定的变量

	$b = 100;

	if(isset($b)){
		echo '$b 存在';
	}

	unset($b);
	if(isset($b)){
		echo '<br>$b 存在';
	}else{
		echo '<br>$b 不存在';
	}

	//empty — 检查一个变量是否为空

	$c = 'hello';
	if(empty($c)){
		echo '<br>$c 为空';
	}else{
		echo '<br>$c 不为空';
	}

	//gettype的基本使用，就是返回某个变量对应的数据类型
	$d = true;
	echo gettype($d);


	$e = array('uu', 'yy', 'gg');
	if(is_array($e)){
		echo '<br>$e 是一个 array';
	}