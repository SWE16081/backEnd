<?php
	header("content-type:text/html;charset=utf-8");
	//php变量命名的说明

	//一般含数字，字母，_组成但是不要以数字开头
	// $1username (错误)
	$user_name13 = '小马';
	$_user_name = '小牛';
	echo $user_name13 . $_user_name;

	//注意
	//1 PHP变量前必须带上$符号
	//2. PHP变量区分大小写,函数不区分大小写
	$address = '北京';
	$Address = '上海';
	echo '<br>';
	var_dump($address, $Address);

	function hello(){
	
		echo 'abc! hello!';
	}

	//函数不区分大小写, 下面都可以调用hello()
	hello();
	Hello();
	HELLo();

	//3. PHP变量命名要有一定含义，常使用英语或者拼音
	$username = '';
	
	//4. 变量命名可以是用它驼峰法(userName)或者下划线法(user_name)或者帕斯卡命名发每个单词首字母大写(UserName)
	//三种方式都ok ,但是我建议，我们写代码时，最好使用同一种风格.

	//5. PHP的变量可以是关键字，但是我们不推荐这样使用 比如 $if

	$if = 123;
	echo $if;

	


