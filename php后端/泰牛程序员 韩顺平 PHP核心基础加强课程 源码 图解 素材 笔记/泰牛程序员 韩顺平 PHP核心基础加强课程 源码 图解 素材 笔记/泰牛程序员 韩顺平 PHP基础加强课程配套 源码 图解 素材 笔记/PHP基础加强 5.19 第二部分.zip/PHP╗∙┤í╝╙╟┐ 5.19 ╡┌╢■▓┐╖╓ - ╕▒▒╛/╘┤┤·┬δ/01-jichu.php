<?php
	header("content-type:text/html;charset=utf-8");
	

	echo 'abc';

	echo 'hello';
	echo 'hello';
	echo 'hello';
	echo 'hello';